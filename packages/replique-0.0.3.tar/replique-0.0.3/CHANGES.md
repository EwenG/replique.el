# Version 0.0.3

- Enable jump-to-definition in the comint buffer of the REPL
- Avoid the split of long messages from the standard output (caused by buffering)
- Exclude the cljs-output-folder when searching for main javascript files
- implement the replique/cljs-repl-connection-script command to connect to the cljs-repl
from any environment, even non clojurescript ones

# Version 0.0.2

* Changes

- Implement stylus, less, sass files reloading
- Update the installation process to use [package.el](https://www.emacswiki.org/emacs/ELPA)

- Also see [replique](https://github.com/EwenG/replique/blob/master/CHANGES.md)