# Finding usages

Use the `replique/logback-reload` command or the `replique.interactive/logback-reload` function to reload the currently loaded logback configuration.